package itis.quiz.spaceships;


import java.util.ArrayList;

// Вы проектируете интеллектуальную систему управления ангаром командного центра.
// Реализуйте интерфейс SpaceshipFleetManager для управления флотом кораблей.
// Используйте СУЩЕСТВУЮЩИЙ интерфейс и класс космического корабля (SpaceshipFleetManager и Spaceship).
public class CommandCenter implements SpaceshipFleetManager {
    @Override
    public Spaceship getMostPowerfulShip(ArrayList<Spaceship> ships) {
        Spaceship mostPowerful = ships.get(0);
        for (int i = 1; i < ships.size(); i++) {
            if(ships.get(i).getFirePower() > mostPowerful.getFirePower()) {
                mostPowerful = ships.get(i);
            }
        }
        return mostPowerful;
    }

    @Override
    public Spaceship getShipByName(ArrayList<Spaceship> ships, String name) {
        for (int i = 0; i < ships.size(); i++) {
            if(ships.get(i).getName().equals(name)) {
                return ships.get(i);
            }
        }
        return null;
    }

    @Override
    public ArrayList<Spaceship> getAllShipsWithEnoughCargoSpace(ArrayList<Spaceship> ships, Integer cargoSize) {
        ArrayList<Spaceship> result = new ArrayList<>();
        for (int i = 0; i < ships.size(); i++) {
            if(ships.get(i).getCargoSpace() >= cargoSize) {
                result.add(ships.get(i));
            }
        }
        return result;
    }

    @Override
    public ArrayList<Spaceship> getAllCivilianShips(ArrayList<Spaceship> ships) {
        ArrayList<Spaceship> result = new ArrayList<>();
        for (int i = 0; i < ships.size(); i++) {
            if(ships.get(i).getFirePower() == 0) {
                result.add(ships.get(i));
            }
        }
        return result;
    }
}
